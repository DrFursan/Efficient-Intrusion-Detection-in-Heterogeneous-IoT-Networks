# Dataset Download Instructions

This directory holds the raw CSV data files.
They are excluded from Git (see `.gitignore`) because of their size.
Download them manually using the links below and place them here.

---

## UNSW-NB15

- **URL:** https://research.unsw.edu.au/projects/unsw-nb15-dataset
- Download the **CSV files** from the Google Drive link on that page.
- Required files (rename after downloading):

| Save as | Original file |
|---------|---------------|
| `UNSW_NB15_training-set.csv` | `UNSW_NB15_training-set.csv` |
| `UNSW_NB15_testing-set.csv`  | `UNSW_NB15_testing-set.csv`  |

---

## BoT-IoT

- **URL:** https://research.unsw.edu.au/projects/bot-iot-dataset
- Download the **"Entire Dataset — CSV Files with features"** archive.
- The full dataset is ~73 million rows. The pipeline uses a stratified 5% sample automatically.
- Concatenate all partial CSV files and save as:

| Save as |
|---------|
| `data/BoT_IoT_Dataset.csv` |

### Quick concatenation (Linux / macOS)

```bash
cd data/
head -1 UNSW_NB15_testing-set.csv > BoT_IoT_Dataset.csv  # header once
for f in Bot-IoT_dataset_*.csv; do tail -n +2 "$f"; done >> BoT_IoT_Dataset.csv
```

---

## Directory contents after setup

```
data/
├── README.md                       ← this file
├── UNSW_NB15_training-set.csv      ← ~175 k rows
├── UNSW_NB15_testing-set.csv       ← ~82 k rows
└── BoT_IoT_Dataset.csv             ← ~73 M rows (5% sample used)
```
