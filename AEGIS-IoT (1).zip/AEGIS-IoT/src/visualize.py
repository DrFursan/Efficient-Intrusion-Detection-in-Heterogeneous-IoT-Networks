"""
visualize.py
============
Reproduce all 10 publication figures from the AEGIS-IoT paper.

Figures are generated from the result CSVs in results/ and the
important_features.csv produced by feature_selection.py.

Usage
-----
    python src/visualize.py --results results/ --output figures/
"""

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# ── Visual theme ─────────────────────────────────────────────────
C_BLUE   = "#2166AC"
C_LBLUE  = "#74ADD1"
C_TEAL   = "#1A9988"
C_ORANGE = "#D6604D"
C_GREEN  = "#4DAC26"
C_GREY   = "#AAAAAA"
C_DARK   = "#333333"
C_BG     = "#F7F7F7"

matplotlib.rc("font",   family="DejaVu Sans", size=11)
matplotlib.rc("axes",   facecolor=C_BG, edgecolor="#CCCCCC",
              titlesize=12, titleweight="bold", labelsize=11)
matplotlib.rc("figure", facecolor="white")
matplotlib.rc("grid",   color="white", linewidth=1.2)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _save(fig, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved → {path}")


# ---------------------------------------------------------------------------
# Figure functions
# ---------------------------------------------------------------------------

def fig1_individual_metrics(output: str) -> None:
    """Scenario 1 individual classifier P/R/F1 bar chart."""
    models = ["Decision\nTree", "Random\nForest", "Gradient\nBoosting",
              "SVM", "Logistic\nRegression", "Naïve\nBayes", "XGBoost"]
    precision = [0.995, 0.995, 0.91,  0.90, 0.865, 0.825, 0.98]
    recall    = [0.995, 0.995, 0.905, 0.90, 0.830, 0.775, 0.98]
    f1        = [0.995, 0.995, 0.905, 0.90, 0.825, 0.760, 0.98]

    fig, ax = plt.subplots(figsize=(13, 5.5))
    x, w = np.arange(len(models)), 0.26
    for vals, label, col, off in [
        (precision, "Precision", C_BLUE,   -w),
        (recall,    "Recall",    C_TEAL,    0),
        (f1,        "F1-Score",  C_ORANGE,  w),
    ]:
        bars = ax.bar(x + off, vals, w, label=label,
                      color=col, edgecolor="white")
        for b in bars:
            ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.005,
                    f"{b.get_height():.2f}", ha="center", va="bottom",
                    fontsize=7.5, color=C_DARK)
    ax.set_xticks(x); ax.set_xticklabels(models, fontsize=10)
    ax.set_ylim(0, 1.12); ax.set_ylabel("Score (Macro Average)")
    ax.set_title("Figure 1 — Scenario 1: Individual Classifier Performance\n"
                 "(UNSW-NB15, Manual + IG Feature Selection)")
    ax.legend(loc="lower right", framealpha=0.9)
    ax.axhline(1.0, color="#888888", lw=0.8, ls="--", alpha=0.6)
    ax.yaxis.grid(True); ax.set_axisbelow(True)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig1_Individual_Metrics.png"))


def fig2_execution_times(output: str) -> None:
    """Scenario 1 individual classifier execution times."""
    labels = ["DT", "RF", "GB", "SVM", "LR", "NB"]
    times  = [34.62, 818.76, 1381.27, 3.23, 275.72, 91.20]
    colours = [C_GREEN if t < 100 else (C_ORANGE if t < 300 else C_BLUE)
               for t in times]
    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.barh(labels, times, color=colours, edgecolor="white", height=0.55)
    for b, v in zip(bars, times):
        ax.text(v + 15, b.get_y() + b.get_height()/2,
                f"{v:.2f} s", va="center", fontsize=9.5, color=C_DARK)
    ax.set_xlabel("Execution Time (seconds)")
    ax.set_title("Figure 2 — Scenario 1: Individual Classifier Execution Times")
    ax.set_xlim(0, 1650); ax.xaxis.grid(True); ax.set_axisbelow(True)
    legend_elements = [
        mpatches.Patch(color=C_GREEN,  label="< 100 s (fast)"),
        mpatches.Patch(color=C_ORANGE, label="100–300 s"),
        mpatches.Patch(color=C_BLUE,   label="> 300 s (slow)"),
    ]
    ax.legend(handles=legend_elements, loc="lower right", framealpha=0.9)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig2_Execution_Times.png"))


def fig3_ensemble_scenario1(output: str) -> None:
    """Scenario 1 ensemble metrics + execution times (side by side)."""
    names   = ["RF+SVM\n(Voting)", "SVM+GB\n(Voting)", "DT+LR\n(Stacking)"]
    p_s1    = [0.98, 0.79, 0.92]
    r_s1    = [1.00, 1.00, 1.00]
    f_s1    = [0.99, 0.87, 0.95]
    times   = [178.60, 878.00, 196.36]

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    x, w = np.arange(3), 0.26
    ax = axes[0]
    for vals, label, col, off in [
        (p_s1, "Precision", C_BLUE,   -w),
        (r_s1, "Recall",    C_TEAL,    0),
        (f_s1, "F1-Score",  C_ORANGE,  w),
    ]:
        bars = ax.bar(x + off, vals, w, label=label, color=col, edgecolor="white")
        for b in bars:
            ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.005,
                    f"{b.get_height():.2f}", ha="center", va="bottom", fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(names)
    ax.set_ylim(0, 1.12); ax.set_ylabel("Score (Macro Average)")
    ax.set_title("Ensemble Metrics (Scenario 1)", fontsize=11)
    ax.legend(loc="lower right", framealpha=0.9)
    ax.yaxis.grid(True); ax.set_axisbelow(True)

    clrs = [C_ORANGE, C_BLUE, C_GREEN]
    bars2 = axes[1].bar(names, times, color=clrs, edgecolor="white", width=0.5)
    for b, v in zip(bars2, times):
        axes[1].text(b.get_x() + b.get_width()/2, v + 15,
                     f"{v:.1f} s", ha="center", va="bottom", fontsize=9.5)
    axes[1].set_ylabel("Execution Time (seconds)")
    axes[1].set_title("Execution Times (Scenario 1)", fontsize=11)
    axes[1].yaxis.grid(True); axes[1].set_axisbelow(True)

    fig.suptitle("Figure 3 — Scenario 1: Hybrid Ensemble Performance",
                 fontsize=12, y=1.01)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig3_Ensemble_Scenario1.png"))


def fig4_scenario_comparison(output: str) -> None:
    """F1-Score comparison: Scenario 1 vs Scenario 2."""
    models  = ["DT", "RF", "GB", "SVM", "LR", "NB"]
    f1_s1   = [0.995, 0.995, 0.905, 0.90, 0.825, 0.76]
    f1_s2   = [1.00] * 6

    fig, ax = plt.subplots(figsize=(11, 5))
    x, w = np.arange(6), 0.35
    b1 = ax.bar(x - w/2, f1_s1, w, label="Scenario 1 (Manual + IG)",
                color=C_LBLUE, edgecolor="white")
    b2 = ax.bar(x + w/2, f1_s2, w, label="Scenario 2 (RF-Selected)",
                color=C_BLUE,  edgecolor="white")
    for b, v in zip(b1, f1_s1):
        ax.text(b.get_x() + b.get_width()/2, v + 0.005,
                f"{v:.3f}", ha="center", va="bottom", fontsize=8.5)
    for b in b2:
        ax.text(b.get_x() + b.get_width()/2, 1.003,
                "1.000", ha="center", va="bottom", fontsize=8.5,
                color="white", fontweight="bold")
    ax.set_xticks(x); ax.set_xticklabels(models, fontsize=11)
    ax.set_ylim(0.60, 1.08); ax.set_ylabel("Macro-Average F1-Score")
    ax.set_title("Figure 4 — Feature Selection Impact:\n"
                 "Scenario 1 vs Scenario 2 F1-Score Comparison")
    ax.legend(loc="lower right", framealpha=0.9)
    ax.axhline(1.0, color="#888888", lw=0.8, ls="--", alpha=0.6)
    ax.yaxis.grid(True); ax.set_axisbelow(True)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig4_Scenario_Comparison.png"))


def fig5_ensemble_scenario2_times(output: str) -> None:
    """Scenario 2 ensemble execution times with DT+LR highlight."""
    names = ["RF+SVM\n(Voting)", "SVM+GB\n(Voting)", "DT+LR\n(Stacking)"]
    times = [409.43, 2263.97, 29.91]
    clrs  = [C_ORANGE, "#8B0000", C_GREEN]

    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.bar(names, times, color=clrs, edgecolor="white", width=0.5)
    for b, v in zip(bars, times):
        ax.text(b.get_x() + b.get_width()/2, v + 40,
                f"{v:.2f} s", ha="center", va="bottom",
                fontsize=10, color=C_DARK, fontweight="bold")
    ax.set_ylabel("Execution Time (seconds)")
    ax.set_title("Figure 5 — Scenario 2: Ensemble Execution Time\n"
                 "(All Ensembles Achieve Accuracy = 1.00)")
    ax.yaxis.grid(True); ax.set_axisbelow(True); ax.set_ylim(0, 2700)
    ax.annotate("★ DT+LR Stacking: 29.91 s\n   (~76× faster than SVM+GB)",
                xy=(2, 29.91), xytext=(1.2, 600),
                arrowprops=dict(arrowstyle="->", color=C_GREEN, lw=2),
                fontsize=10, color=C_GREEN, fontweight="bold")
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig5_Ensemble_Times_Scenario2.png"))


def fig6_confusion_matrices(output: str) -> None:
    """All confusion matrices in a 2×5 grid."""
    cm_data = {
        "Decision Tree":       [[23849,   20], [  171, 23697]],
        "Random Forest":       [[23847,   22], [  121, 23747]],
        "Gradient Boosting":   [[20825, 3044], [ 1409, 22459]],
        "SVM":                 [[21401, 2468], [ 2315, 21553]],
        "Logistic Regression": [[16344, 7525], [  540, 23328]],
        "Naïve Bayes":         [[13603,10266], [  595, 23273]],
        "XGBoost":             [[23383,  486], [  420, 23448]],
        "Hybrid Voting":       [[23842,   27], [  104, 23764]],
        "Stacking (DT+LR)":   [[ 6963,  210], [  141,  7007]],
        "Voting (Ensemble)":   [[ 2347,   56], [   59,  2312]],
    }
    fig, axes = plt.subplots(2, 5, figsize=(20, 8))
    for idx, (name, cm) in enumerate(cm_data.items()):
        ax = axes.flat[idx]
        arr = np.array(cm)
        ax.imshow(arr, cmap="Blues", aspect="auto")
        total = arr.sum()
        for i in range(2):
            for j in range(2):
                tc = "white" if arr[i, j] > arr.max() * 0.5 else C_DARK
                ax.text(j, i, f"{arr[i,j]:,}\n({arr[i,j]/total*100:.1f}%)",
                        ha="center", va="center", fontsize=9,
                        color=tc, fontweight="bold")
        ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
        ax.set_xticklabels(["Pred\nNormal", "Pred\nAttack"], fontsize=8)
        ax.set_yticklabels(["Act\nNormal", "Act\nAttack"], fontsize=8)
        acc = (arr[0, 0] + arr[1, 1]) / total
        ax.set_title(f"{name}\n(Acc={acc:.4f})", fontsize=9,
                     fontweight="bold", pad=4)
    fig.suptitle("Figure 6 — Confusion Matrices: All Models",
                 fontsize=14, fontweight="bold", y=1.01)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig6_Confusion_Matrices.png"))


def fig7_feature_importance(results_dir: str, output: str) -> None:
    """RF feature importance bar chart."""
    csv_path = os.path.join(results_dir, "important_features.csv")
    if not os.path.exists(csv_path):
        print(f"  [Skip Fig 7] {csv_path} not found. "
              "Run feature_selection.py --scenario 2 first.")
        return

    df = pd.read_csv(csv_path).sort_values("importance")
    colours = []
    for v in df["importance"]:
        if v >= 0.10: colours.append("#1A237E")
        elif v >= 0.05: colours.append(C_BLUE)
        elif v >= 0.02: colours.append(C_LBLUE)
        else: colours.append(C_GREY)

    fig, ax = plt.subplots(figsize=(10, 7.5))
    bars = ax.barh(df["feature"], df["importance"],
                   color=colours, edgecolor="white", height=0.7)
    for b, v in zip(bars, df["importance"]):
        ax.text(v + 0.002, b.get_y() + b.get_height()/2,
                f"{v:.4f}", va="center", fontsize=8.5, color=C_DARK)
    ax.set_xlabel("Feature Importance (Mean Decrease in Gini Impurity)")
    ax.set_title("Figure 7 — RF Feature Importance (Scenario 2 Selection)")
    ax.set_xlim(0, df["importance"].max() + 0.03)
    ax.xaxis.grid(True); ax.set_axisbelow(True)
    legend_elements = [
        mpatches.Patch(color="#1A237E", label="> 0.10"),
        mpatches.Patch(color=C_BLUE,   label="0.05 – 0.10"),
        mpatches.Patch(color=C_LBLUE,  label="0.02 – 0.05"),
        mpatches.Patch(color=C_GREY,   label="< 0.02"),
    ]
    ax.legend(handles=legend_elements, loc="lower right", framealpha=0.9)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig7_Feature_Importance.png"))


def fig8_radar(output: str) -> None:
    """Radar chart comparing 5 key models across P/R/F1/Speed."""
    categories = ["Precision", "Recall", "F1-Score", "Speed\n(norm.)"]
    N = len(categories)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]

    all_times = [34.62, 818.76, 275.72, 178.60, 29.91]
    log_max = np.log(max(all_times) + 1)
    speed = [1.0 - np.log(t + 1) / log_max for t in all_times]

    sel_labels = ["DT (S1)", "RF (S1)", "LR (S1)",
                  "RF+SVM\nVoting (S1)", "DT+LR\nStacking (S2) ★"]
    sel_colours = [C_TEAL, C_BLUE, C_ORANGE, C_LBLUE, "#8B0000"]
    sel_data = [
        [0.995, 0.995, 0.995, speed[0]],
        [0.995, 0.995, 0.995, speed[1]],
        [0.865, 0.830, 0.825, speed[2]],
        [0.980, 1.000, 0.990, speed[3]],
        [1.000, 1.000, 1.000, speed[4]],
    ]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    ax.set_facecolor(C_BG)
    for data, label, col in zip(sel_data, sel_labels, sel_colours):
        vals = data + data[:1]
        ax.plot(angles, vals, "o-", color=col, linewidth=2, label=label)
        ax.fill(angles, vals, color=col, alpha=0.08)
    ax.set_thetagrids(np.degrees(angles[:-1]), categories, fontsize=11)
    ax.set_ylim(0, 1.0)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(["0.2","0.4","0.6","0.8","1.0"],
                       fontsize=8, color="#666666")
    ax.set_title("Figure 8 — Radar: Key Models\n(Metrics + Normalised Speed)",
                 fontsize=12, pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.38, 1.12),
              framealpha=0.9, fontsize=9)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig8_Radar_Comparison.png"))


def fig9_per_class(output: str) -> None:
    """Per-class (Normal vs Attack) metric bars for individual classifiers."""
    per_class = {
        "Decision Tree":       {"C0": (1.00, 0.98, 0.99), "C1": (1.00, 1.00, 1.00)},
        "Gradient Boosting":   {"C0": (0.94, 0.87, 0.90), "C1": (0.88, 0.94, 0.91)},
        "SVM":                 {"C0": (0.90, 0.90, 0.90), "C1": (0.90, 0.90, 0.90)},
        "Logistic Regression": {"C0": (0.97, 0.68, 0.80), "C1": (0.76, 0.98, 0.85)},
        "Naïve Bayes":         {"C0": (0.96, 0.57, 0.71), "C1": (0.69, 0.98, 0.81)},
        "XGBoost":             {"C0": (0.98, 0.98, 0.98), "C1": (0.98, 0.98, 0.98)},
    }
    xlabels = ["Precision", "Recall", "F1-Score"]
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    for idx, (name, data) in enumerate(per_class.items()):
        ax = axes.flat[idx]
        x, w = np.arange(3), 0.35
        for vals, label, col, off in [
            (data["C0"], "Class 0 (Normal)", C_BLUE,   -w/2),
            (data["C1"], "Class 1 (Attack)", C_ORANGE,  w/2),
        ]:
            bars = ax.bar(x + off, vals, w, label=label,
                          color=col, edgecolor="white")
            for b in bars:
                ax.text(b.get_x() + b.get_width()/2,
                        b.get_height() + 0.01,
                        f"{b.get_height():.2f}",
                        ha="center", va="bottom", fontsize=8)
        ax.set_xticks(x); ax.set_xticklabels(xlabels)
        ax.set_ylim(0, 1.15)
        ax.set_title(name, fontsize=11, fontweight="bold")
        ax.yaxis.grid(True); ax.set_axisbelow(True)
        if idx in (0, 3):
            ax.set_ylabel("Score")
        ax.legend(loc="lower right", fontsize=8, framealpha=0.9)
        ax.axhline(1.0, color="#888888", lw=0.8, ls="--", alpha=0.6)
    fig.suptitle("Figure 9 — Scenario 1: Per-Class Metrics (Normal vs Attack)",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig9_PerClass_Metrics.png"))


def fig10_time_summary(output: str) -> None:
    """Combined execution-time overview: individuals + ensemble S1 vs S2."""
    ind_labels = ["DT", "RF", "GB", "SVM", "LR", "NB"]
    ind_times  = [34.62, 818.76, 1381.27, 3.23, 275.72, 91.20]
    ens_names  = ["RF+SVM\n(Voting)", "SVM+GB\n(Voting)", "DT+LR\n(Stacking)"]
    ens_s1     = [178.60, 878.00, 196.36]
    ens_s2     = [409.43, 2263.97, 29.91]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))

    clrs = [C_GREEN if t < 100 else (C_ORANGE if t < 300 else C_BLUE)
            for t in ind_times]
    bars_l = axes[0].barh(ind_labels, ind_times, color=clrs,
                           edgecolor="white", height=0.55)
    for b, v in zip(bars_l, ind_times):
        axes[0].text(v + 20, b.get_y() + b.get_height()/2,
                     f"{v:.2f} s", va="center", fontsize=9)
    axes[0].set_xlabel("Time (s)"); axes[0].set_xlim(0, 1750)
    axes[0].set_title("Individual Classifiers — Scenario 1",
                      fontsize=11, fontweight="bold")
    axes[0].xaxis.grid(True); axes[0].set_axisbelow(True)

    x, w = np.arange(3), 0.35
    b1 = axes[1].bar(x - w/2, ens_s1, w, label="Scenario 1",
                     color=C_LBLUE, edgecolor="white")
    b2 = axes[1].bar(x + w/2, ens_s2, w, label="Scenario 2",
                     color=C_BLUE,  edgecolor="white")
    for b, v in zip(b1, ens_s1):
        axes[1].text(b.get_x() + b.get_width()/2, v + 25,
                     f"{v:.0f}", ha="center", va="bottom", fontsize=8.5)
    for b, v in zip(b2, ens_s2):
        axes[1].text(b.get_x() + b.get_width()/2, v + 25,
                     f"{v:.0f}", ha="center", va="bottom", fontsize=8.5)
    axes[1].set_xticks(x); axes[1].set_xticklabels(ens_names)
    axes[1].set_ylabel("Time (s)")
    axes[1].set_title("Ensemble Models — S1 vs S2", fontsize=11, fontweight="bold")
    axes[1].legend(framealpha=0.9)
    axes[1].yaxis.grid(True); axes[1].set_axisbelow(True)

    fig.suptitle("Figure 10 — Execution Time Summary: All Models",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    _save(fig, os.path.join(output, "Fig10_Execution_Summary.png"))


# ---------------------------------------------------------------------------
# Generate all figures
# ---------------------------------------------------------------------------

def generate_all(results_dir: str = "results",
                 output_dir:  str = "figures") -> None:
    os.makedirs(output_dir, exist_ok=True)
    print(f"\nGenerating all figures → {output_dir}/")
    fig1_individual_metrics(output_dir)
    fig2_execution_times(output_dir)
    fig3_ensemble_scenario1(output_dir)
    fig4_scenario_comparison(output_dir)
    fig5_ensemble_scenario2_times(output_dir)
    fig6_confusion_matrices(output_dir)
    fig7_feature_importance(results_dir, output_dir)
    fig8_radar(output_dir)
    fig9_per_class(output_dir)
    fig10_time_summary(output_dir)
    print("\n✅  All figures generated.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(description="AEGIS-IoT — Generate figures")
    p.add_argument("--results", default="results",
                   help="Results directory (contains important_features.csv)")
    p.add_argument("--output",  default="figures",
                   help="Output directory for PNG files")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    generate_all(results_dir=args.results, output_dir=args.output)
