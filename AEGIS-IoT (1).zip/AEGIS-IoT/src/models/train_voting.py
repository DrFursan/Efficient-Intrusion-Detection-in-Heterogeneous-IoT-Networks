"""
train_voting.py
===============
Hard Voting ensembles used in AEGIS-IoT:

    rf_svm  – RandomForest + SVM  (Scenario 1 & 2)
    svm_gb  – SVM + GradientBoosting  (Scenario 1 & 2)

Both use sklearn's VotingClassifier with voting='hard'.

Usage
-----
    python src/models/train_voting.py --combo rf_svm \
        --input data/unsw_scenario2_features.csv

    python src/models/train_voting.py --combo svm_gb \
        --input data/unsw_scenario2_features.csv

    python src/models/train_voting.py --combo all \
        --input data/unsw_scenario2_features.csv
"""

import argparse
import os
import pickle
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    GradientBoostingClassifier,
    RandomForestClassifier,
    VotingClassifier,
)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.svm import SVC

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.evaluate import (
    Timer,
    compute_metrics,
    plot_confusion_matrix,
    print_metrics,
    save_classification_report_csv,
    save_confusion_matrix_csv,
    save_results_txt,
)


# ---------------------------------------------------------------------------
# Ensemble factory
# ---------------------------------------------------------------------------

def build_voting_clf(combo: str,
                     random_state: int = 42) -> VotingClassifier:
    """Return the requested VotingClassifier.

    Parameters
    ----------
    combo : str  'rf_svm' or 'svm_gb'
    """
    rf_clf = RandomForestClassifier(
        n_estimators=100, random_state=random_state, n_jobs=-1
    )
    svm_clf = SVC(
        kernel="linear", probability=True,
        random_state=random_state,
        class_weight="balanced",
    )
    gb_clf = GradientBoostingClassifier(
        n_estimators=100, learning_rate=0.1, random_state=random_state
    )

    if combo == "rf_svm":
        estimators = [("rf", rf_clf), ("svm", svm_clf)]
        name = "Voting_RF_SVM"
    elif combo == "svm_gb":
        estimators = [("svm", svm_clf), ("gb", gb_clf)]
        name = "Voting_SVM_GB"
    else:
        raise ValueError(f"Unknown combo: '{combo}'. "
                         "Choose 'rf_svm' or 'svm_gb'.")

    clf = VotingClassifier(estimators=estimators, voting="hard")
    return clf, name


# ---------------------------------------------------------------------------
# Training pipeline
# ---------------------------------------------------------------------------

def train_voting(combo: str,
                 X_train, y_train,
                 X_test,  y_test,
                 results_dir: str = "results",
                 models_dir:  str = "saved_models",
                 cv_folds:    int = 5) -> dict:
    """Train, evaluate, and save a voting ensemble.

    Returns a metrics dict.
    """
    clf, model_name = build_voting_clf(combo)
    file_tag = combo   # used in file names

    print(f"\n{'='*55}")
    print(f"  Training: {model_name}")
    print(f"{'='*55}")

    os.makedirs(results_dir, exist_ok=True)
    os.makedirs(models_dir,  exist_ok=True)

    # ── Cross-validation ─────────────────────────────────────────
    print(f"  Running {cv_folds}-fold CV (F1-weighted) …")
    cv_scores = cross_val_score(
        clf, X_train, y_train,
        cv=cv_folds, scoring="f1_weighted", n_jobs=-1,
    )
    print(f"  CV F1 scores : {np.round(cv_scores, 4)}")
    print(f"  Mean CV F1   : {cv_scores.mean():.4f} "
          f"(± {cv_scores.std():.4f})")

    # ── Training ─────────────────────────────────────────────────
    print(f"  Fitting {model_name} …")
    with Timer() as t:
        clf.fit(X_train, y_train)

    # ── Evaluation ───────────────────────────────────────────────
    y_pred  = clf.predict(X_test)
    metrics = compute_metrics(y_test, y_pred)
    metrics["time"] = t.elapsed
    print_metrics(metrics, model_name)

    train_acc = clf.score(X_train, y_train)
    print(f"  Train accuracy : {train_acc:.4f}")
    print(f"  Test  accuracy : {metrics['accuracy']:.4f}")

    # ── Save artefacts ───────────────────────────────────────────
    cm = plot_confusion_matrix(
        y_test, y_pred,
        model_name=model_name,
        save_path=os.path.join(results_dir,
                               f"confusion_matrix_voting_{file_tag}.png"),
    )
    save_classification_report_csv(
        y_test, y_pred,
        csv_path=os.path.join(results_dir,
                               f"classification_report_voting_{file_tag}.csv"),
    )
    save_confusion_matrix_csv(
        cm,
        csv_path=os.path.join(results_dir,
                               f"confusion_matrix_voting_{file_tag}.csv"),
    )
    save_results_txt(
        metrics, y_test, y_pred, cm, t.elapsed,
        model_name=model_name,
        txt_path=os.path.join(results_dir,
                               f"model_results_voting_{file_tag}.txt"),
    )

    model_path = os.path.join(models_dir,
                               f"voting_{file_tag}_model.pkl")
    with open(model_path, "wb") as f:
        pickle.dump(clf, f)
    print(f"  Model saved → {model_path}")

    # ── Verify ───────────────────────────────────────────────────
    with open(model_path, "rb") as f:
        loaded = pickle.load(f)
    verify_acc = loaded.score(X_test, y_test)
    print(f"  Verified loaded model accuracy: {verify_acc:.4f}")

    return metrics


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(
        description="AEGIS-IoT — Hard Voting Ensemble"
    )
    p.add_argument("--combo",      default="rf_svm",
                   choices=["rf_svm", "svm_gb", "all"],
                   help="Which ensemble to train (default: rf_svm)")
    p.add_argument("--input",      required=True,
                   help="Feature-selected CSV")
    p.add_argument("--label",      default="label")
    p.add_argument("--test_size",  type=float, default=0.2)
    p.add_argument("--sample",     type=float, default=0.10,
                   help="Fraction of data to use (default: 0.10 — "
                        "keeps SVM tractable)")
    p.add_argument("--results",    default="results")
    p.add_argument("--models_dir", default="saved_models")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    df = pd.read_csv(args.input)
    if args.sample < 1.0:
        df = df.sample(frac=args.sample, random_state=42).reset_index(drop=True)
        print(f"Using {len(df):,} rows ({args.sample*100:.0f}% sample)")

    X = df.drop(columns=[args.label]).values
    y = df[args.label]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=y
    )
    print(f"Train: {len(X_train):,}   Test: {len(X_test):,}")
    print(f"Class distribution (train):\n{y_train.value_counts().to_dict()}")

    combos = ["rf_svm", "svm_gb"] if args.combo == "all" else [args.combo]
    all_results = {}

    for combo in combos:
        result = train_voting(
            combo=combo,
            X_train=X_train, y_train=y_train,
            X_test=X_test,   y_test=y_test,
            results_dir=args.results,
            models_dir=args.models_dir,
        )
        all_results[combo] = result

    # ── Summary ───────────────────────────────────────────────────
    print("\n" + "=" * 65)
    print(f"  {'Ensemble':<25} {'Acc':>7} {'F1':>7} {'Time(s)':>10}")
    print("=" * 65)
    for combo, m in all_results.items():
        _, name = build_voting_clf(combo)
        print(f"  {name:<25} {m['accuracy']:>7.4f} "
              f"{m['f1']:>7.4f} {m.get('time', 0):>10.2f}")
    print("=" * 65)
