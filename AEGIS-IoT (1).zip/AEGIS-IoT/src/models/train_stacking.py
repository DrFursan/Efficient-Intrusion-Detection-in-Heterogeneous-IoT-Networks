"""
train_stacking.py
=================
DT + LR Stacking ensemble — the optimal model in the AEGIS-IoT paper.

Architecture
------------
    Base estimators : DecisionTreeClassifier  (level-0)
                      RandomForestClassifier  (level-0)
    Meta-learner    : LogisticRegression       (level-1)

The paper's Scenario 2 result with this ensemble:
    Accuracy = 1.000 | F1 = 1.000 | Time = 29.91 s

Usage
-----
    python src/models/train_stacking.py \
        --input data/unsw_scenario2_features.csv \
        --label label \
        --sample 0.30
"""

import argparse
import os
import pickle
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.tree import DecisionTreeClassifier

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.evaluate import (
    Timer,
    compute_metrics,
    plot_confusion_matrix,
    print_metrics,
    save_classification_report_csv,
    save_confusion_matrix_csv,
    save_results_txt,
)


# ---------------------------------------------------------------------------
# Build stacking ensemble
# ---------------------------------------------------------------------------

def build_stacking_clf(random_state: int = 42) -> StackingClassifier:
    """Return the DT + RF → LR stacking classifier used in the paper."""
    dt_clf = DecisionTreeClassifier(
        random_state=random_state,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=5,
    )
    rf_clf = RandomForestClassifier(
        n_estimators=100,
        random_state=random_state,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=5,
        n_jobs=-1,
    )
    meta_model = LogisticRegression(
        random_state=random_state,
        max_iter=1000,
        solver="lbfgs",
    )
    return StackingClassifier(
        estimators=[("dt", dt_clf), ("rf", rf_clf)],
        final_estimator=meta_model,
        cv=5,
        n_jobs=-1,
    )


# ---------------------------------------------------------------------------
# Training pipeline
# ---------------------------------------------------------------------------

def train_stacking(X_train, y_train, X_test, y_test,
                   results_dir: str = "results",
                   models_dir:  str = "saved_models",
                   cv_folds:    int = 5) -> dict:
    """Train, evaluate, and save the stacking ensemble.

    Returns a metrics dict.
    """
    model_name = "Stacking_DT_LR"
    print(f"\n{'='*55}")
    print(f"  Training: {model_name}")
    print(f"{'='*55}")

    os.makedirs(results_dir, exist_ok=True)
    os.makedirs(models_dir,  exist_ok=True)

    clf = build_stacking_clf()

    # ── Cross-validation ─────────────────────────────────────────
    print(f"  Running {cv_folds}-fold CV (F1-weighted) …")
    cv_scores = cross_val_score(
        clf, X_train, y_train,
        cv=cv_folds, scoring="f1_weighted", n_jobs=-1,
    )
    print(f"  CV F1 scores : {np.round(cv_scores, 4)}")
    print(f"  Mean CV F1   : {cv_scores.mean():.4f} "
          f"(± {cv_scores.std():.4f})")

    # ── Training ─────────────────────────────────────────────────
    print("  Fitting stacking classifier …")
    with Timer() as t:
        clf.fit(X_train, y_train)

    # ── Evaluation ───────────────────────────────────────────────
    y_pred = clf.predict(X_test)
    metrics = compute_metrics(y_test, y_pred)
    metrics["time"] = t.elapsed
    print_metrics(metrics, model_name)

    train_acc = clf.score(X_train, y_train)
    print(f"  Train accuracy : {train_acc:.4f}")
    print(f"  Test  accuracy : {metrics['accuracy']:.4f}")

    # ── Save artefacts ───────────────────────────────────────────
    cm = plot_confusion_matrix(
        y_test, y_pred,
        model_name=model_name,
        save_path=os.path.join(results_dir,
                               f"confusion_matrix_stacking.png"),
    )
    save_classification_report_csv(
        y_test, y_pred,
        csv_path=os.path.join(results_dir,
                               "classification_report_stacking.csv"),
    )
    save_confusion_matrix_csv(
        cm,
        csv_path=os.path.join(results_dir,
                               "confusion_matrix_stacking.csv"),
    )
    save_results_txt(
        metrics, y_test, y_pred, cm, t.elapsed,
        model_name=model_name,
        txt_path=os.path.join(results_dir,
                               "model_results_stacking.txt"),
    )

    model_path = os.path.join(models_dir, "stacking_model.pkl")
    with open(model_path, "wb") as f:
        pickle.dump(clf, f)
    print(f"  Model saved → {model_path}")

    # ── Verify saved model ───────────────────────────────────────
    with open(model_path, "rb") as f:
        loaded = pickle.load(f)
    verify_acc = loaded.score(X_test, y_test)
    print(f"  Verified loaded model accuracy: {verify_acc:.4f}")

    return metrics


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(
        description="AEGIS-IoT — DT+LR Stacking Ensemble"
    )
    p.add_argument("--input",      required=True,
                   help="Feature-selected CSV")
    p.add_argument("--label",      default="label")
    p.add_argument("--test_size",  type=float, default=0.2)
    p.add_argument("--sample",     type=float, default=0.30,
                   help="Fraction of data to use for training "
                        "(default: 0.30 — matches paper)")
    p.add_argument("--results",    default="results")
    p.add_argument("--models_dir", default="saved_models")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    df = pd.read_csv(args.input)
    if args.sample < 1.0:
        df = df.sample(frac=args.sample, random_state=42).reset_index(drop=True)
        print(f"Using {len(df):,} rows ({args.sample*100:.0f}% sample)")

    X = df.drop(columns=[args.label]).values
    y = df[args.label]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=y
    )
    print(f"Train: {len(X_train):,}   Test: {len(X_test):,}")
    print(f"Class distribution (train):\n{y_train.value_counts().to_dict()}")

    metrics = train_stacking(
        X_train, y_train, X_test, y_test,
        results_dir=args.results,
        models_dir=args.models_dir,
    )
