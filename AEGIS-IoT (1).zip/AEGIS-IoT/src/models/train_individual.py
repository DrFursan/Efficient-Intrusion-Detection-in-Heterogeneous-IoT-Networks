"""
train_individual.py
===================
Train and evaluate all seven individual classifiers used in AEGIS-IoT:

    rf   – Random Forest
    dt   – Decision Tree
    svm  – Support Vector Machine
    nb   – Naïve Bayes (Gaussian)
    lr   – Logistic Regression
    gb   – Gradient Boosting (HistGradientBoosting)
    xgb  – XGBoost

Each classifier follows the same workflow:
    1. Load the selected-feature CSV produced by feature_selection.py
    2. Split into train / test (80 / 20, stratified)
    3. Apply SMOTE on the training set to handle class imbalance
    4. Perform 5-fold stratified cross-validation
    5. Train on the full training set
    6. Evaluate on the held-out test set
    7. Save model (.pkl), CSV report, confusion matrix, and TXT summary

Usage
-----
    # Train a specific model
    python src/models/train_individual.py --model rf \
        --input data/unsw_scenario1_features.csv \
        --label label --results results/ --models_dir saved_models/

    # Train all seven models sequentially
    python src/models/train_individual.py --model all \
        --input data/unsw_scenario1_features.csv
"""

import argparse
import os

import joblib
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.ensemble import (
    GradientBoostingClassifier,
    HistGradientBoostingClassifier,
    RandomForestClassifier,
)
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

try:
    from xgboost import XGBClassifier
    _XGBOOST_AVAILABLE = True
except ImportError:
    _XGBOOST_AVAILABLE = False
    print("Warning: xgboost not installed. XGB model will be skipped.")

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.evaluate import (
    Timer,
    compute_metrics,
    plot_confusion_matrix,
    print_metrics,
    save_classification_report_csv,
    save_confusion_matrix_csv,
    save_results_txt,
)

# ---------------------------------------------------------------------------
# Model factory
# ---------------------------------------------------------------------------

def build_model(name: str):
    """Return an untrained sklearn-compatible estimator."""
    name = name.lower()
    if name == "rf":
        return RandomForestClassifier(
            n_estimators=100,
            random_state=42,
            class_weight="balanced",
            n_jobs=-1,
        )
    if name == "dt":
        return DecisionTreeClassifier(
            random_state=42,
            max_depth=10,
            min_samples_split=10,
            min_samples_leaf=5,
            criterion="gini",
            class_weight="balanced",
        )
    if name == "svm":
        # SVM is slow on large datasets — use a linear kernel for speed
        return SVC(
            kernel="linear",
            random_state=42,
            class_weight="balanced",
            probability=True,
        )
    if name == "nb":
        return GaussianNB()
    if name == "lr":
        return LogisticRegression(
            max_iter=1000,
            random_state=42,
            class_weight="balanced",
            solver="lbfgs",
        )
    if name == "gb":
        # HistGradientBoosting handles missing values natively and is faster
        return HistGradientBoostingClassifier(
            max_iter=100,
            random_state=42,
        )
    if name == "xgb":
        if not _XGBOOST_AVAILABLE:
            raise ImportError("xgboost is not installed.")
        return XGBClassifier(
            n_estimators=100,
            use_label_encoder=False,
            eval_metric="logloss",
            random_state=42,
            n_jobs=-1,
        )
    raise ValueError(f"Unknown model name: '{name}'. "
                     f"Choose from: rf, dt, svm, nb, lr, gb, xgb")


FRIENDLY_NAMES = {
    "rf":  "RandomForest",
    "dt":  "DecisionTree",
    "svm": "SVM",
    "nb":  "NaiveBayes",
    "lr":  "LogisticRegression",
    "gb":  "GradientBoosting",
    "xgb": "XGBoost",
}

# ---------------------------------------------------------------------------
# Training pipeline
# ---------------------------------------------------------------------------

def train_classifier(model_key: str,
                     X_train: np.ndarray,
                     y_train: pd.Series,
                     X_test: np.ndarray,
                     y_test: pd.Series,
                     feature_names: list,
                     results_dir: str = "results",
                     models_dir: str = "saved_models",
                     apply_smote: bool = True,
                     cv_folds: int = 5) -> dict:
    """Full train-evaluate-save cycle for one classifier.

    Returns a dict with metrics and elapsed time.
    """
    model_name = FRIENDLY_NAMES.get(model_key, model_key)
    print(f"\n{'='*55}")
    print(f"  Training: {model_name}")
    print(f"{'='*55}")

    os.makedirs(results_dir, exist_ok=True)
    os.makedirs(models_dir,  exist_ok=True)

    # ── SMOTE oversampling ────────────────────────────────────────
    if apply_smote:
        smote = SMOTE(random_state=42)
        X_res, y_res = smote.fit_resample(X_train, y_train)
        print(f"  After SMOTE: {X_res.shape[0]:,} training samples")
    else:
        X_res, y_res = X_train, y_train

    clf = build_model(model_key)

    # ── Cross-validation ─────────────────────────────────────────
    print(f"  Running {cv_folds}-fold stratified CV …")
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
    cv_scores = cross_val_score(clf, X_res, y_res, cv=skf,
                                scoring="f1_weighted", n_jobs=-1)
    print(f"  CV F1 scores : {np.round(cv_scores, 4)}")
    print(f"  Mean CV F1   : {cv_scores.mean():.4f} "
          f"(± {cv_scores.std():.4f})")

    # ── Training ─────────────────────────────────────────────────
    print(f"  Fitting {model_name} …")
    with Timer() as t:
        clf.fit(X_res, y_res)

    # ── Evaluation ───────────────────────────────────────────────
    y_pred   = clf.predict(X_test)
    metrics  = compute_metrics(y_test, y_pred)
    metrics["time"] = t.elapsed
    print_metrics(metrics, model_name)

    # ── Save artefacts ───────────────────────────────────────────
    prefix = os.path.join(results_dir, f"classification{model_name}")

    cm = plot_confusion_matrix(
        y_test, y_pred,
        model_name=model_name,
        save_path=os.path.join(results_dir,
                               f"confusion_matrix_{model_name}.png"),
    )
    save_classification_report_csv(
        y_test, y_pred,
        csv_path=f"{prefix}_report.csv",
    )
    save_confusion_matrix_csv(
        cm,
        csv_path=os.path.join(results_dir,
                               f"confusion_matrix_{model_name}.csv"),
    )
    save_results_txt(
        metrics, y_test, y_pred, cm, t.elapsed,
        model_name=model_name,
        txt_path=os.path.join(results_dir,
                               f"model_results_{model_name}.txt"),
    )

    model_path = os.path.join(models_dir, f"{model_name.lower()}_model.pkl")
    joblib.dump(clf, model_path)
    print(f"  Model saved → {model_path}")

    return metrics


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

ALL_MODELS = ["rf", "dt", "svm", "nb", "lr", "gb", "xgb"]


def _parse_args():
    p = argparse.ArgumentParser(
        description="AEGIS-IoT — Train individual classifiers"
    )
    p.add_argument("--model",       default="rf",
                   help=f"Model key or 'all'. Options: "
                        f"{', '.join(ALL_MODELS)} (default: rf)")
    p.add_argument("--input",       required=True,
                   help="Feature-selected CSV (label column required)")
    p.add_argument("--label",       default="label",
                   help="Label column name (default: label)")
    p.add_argument("--test_size",   type=float, default=0.2,
                   help="Test split fraction (default: 0.2)")
    p.add_argument("--results",     default="results",
                   help="Directory for reports and matrices")
    p.add_argument("--models_dir",  default="saved_models",
                   help="Directory for saved .pkl models")
    p.add_argument("--no_smote",    action="store_true",
                   help="Disable SMOTE oversampling")
    p.add_argument("--svm_sample",  type=float, default=0.1,
                   help="Fraction of training data used for SVM "
                        "(for speed; default: 0.1)")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    df = pd.read_csv(args.input)
    X  = df.drop(columns=[args.label])
    y  = df[args.label]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size,
        random_state=42, stratify=y
    )
    print(f"Train: {X_train.shape[0]:,}   Test: {X_test.shape[0]:,}")

    models_to_run = ALL_MODELS if args.model == "all" else [args.model]
    all_results   = {}

    for key in models_to_run:
        if key == "xgb" and not _XGBOOST_AVAILABLE:
            print("Skipping XGBoost (not installed).")
            continue

        # For SVM, subsample training data to keep it tractable
        if key == "svm" and args.svm_sample < 1.0:
            n_svm = int(len(X_train) * args.svm_sample)
            idx   = np.random.RandomState(42).choice(
                len(X_train), n_svm, replace=False
            )
            Xtr = X_train.iloc[idx]
            ytr = y_train.iloc[idx]
            print(f"  SVM: using {n_svm:,} training samples "
                  f"({args.svm_sample*100:.0f}%)")
        else:
            Xtr, ytr = X_train, y_train

        result = train_classifier(
            model_key=key,
            X_train=Xtr.values,
            y_train=ytr,
            X_test=X_test.values,
            y_test=y_test,
            feature_names=X.columns.tolist(),
            results_dir=args.results,
            models_dir=args.models_dir,
            apply_smote=not args.no_smote,
        )
        all_results[key] = result

    # ── Summary table ─────────────────────────────────────────────
    print("\n\n" + "=" * 65)
    print(f"  {'Model':<22} {'Acc':>7} {'Prec':>7} "
          f"{'Rec':>7} {'F1':>7} {'Time(s)':>10}")
    print("=" * 65)
    for key, m in all_results.items():
        name = FRIENDLY_NAMES.get(key, key)
        print(f"  {name:<22} {m['accuracy']:>7.4f} {m['precision']:>7.4f} "
              f"{m['recall']:>7.4f} {m['f1']:>7.4f} "
              f"{m.get('time', 0):>10.2f}")
    print("=" * 65)
