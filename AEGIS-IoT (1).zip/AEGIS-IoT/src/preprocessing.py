"""
preprocessing.py
================
Data loading, cleaning, encoding, and scaling for the AEGIS-IoT pipeline.

Supports both UNSW-NB15 and BoT-IoT datasets.

Usage
-----
    python src/preprocessing.py --input data/UNSW_NB15_testing-set.csv \
                                 --dataset unsw \
                                 --output data/unsw_preprocessed.csv
"""

import argparse
import os

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder, StandardScaler

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

UNSW_LABEL_COL = "label"          # binary: 0 = normal, 1 = attack
BOT_LABEL_COL  = "attack"         # binary: 0 = normal, 1 = attack

UNSW_DROP_COLS = ["id", "attack_cat"]
BOT_DROP_COLS  = ["pkSeqID"]

# Columns that are IP/MAC addresses — not useful as raw features
NON_NUMERIC_ADDR = ["saddr", "daddr", "smac", "dmac"]

UNSW_CAT_COLS = ["proto", "service", "state"]
BOT_CAT_COLS  = ["proto", "flgs", "state", "category", "subcategory"]

# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def load_data(file_path: str, sample_frac: float = 1.0,
              random_state: int = 42) -> pd.DataFrame:
    """Load a CSV dataset, with optional stratified sampling.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.
    sample_frac : float
        Fraction of rows to keep (default 1.0 = all rows).
        For BoT-IoT use 0.05 (5%) to keep compute tractable.
    random_state : int
        Random seed for reproducible sampling.

    Returns
    -------
    pd.DataFrame
    """
    print(f"Loading data from: {file_path}")
    df = pd.read_csv(file_path)
    print(f"  Loaded  : {df.shape[0]:,} rows × {df.shape[1]} columns")

    if sample_frac < 1.0:
        df = df.sample(frac=sample_frac, random_state=random_state)
        df = df.reset_index(drop=True)
        print(f"  Sampled : {df.shape[0]:,} rows (frac={sample_frac})")

    return df


def drop_irrelevant_columns(df: pd.DataFrame,
                             dataset: str = "unsw") -> pd.DataFrame:
    """Drop columns that are identifiers or redundant for ML."""
    cols_to_drop = (UNSW_DROP_COLS if dataset == "unsw" else BOT_DROP_COLS)
    cols_to_drop += NON_NUMERIC_ADDR
    existing = [c for c in cols_to_drop if c in df.columns]
    df = df.drop(columns=existing, errors="ignore")
    print(f"  Dropped irrelevant columns: {existing}")
    return df


def convert_hex_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Convert hexadecimal string values (e.g. '0x1f') to integers."""
    for col in df.select_dtypes(include="object").columns:
        mask = df[col].str.contains(r"^0x", regex=True, na=False)
        if mask.any():
            print(f"  Converting hex column: {col}")
            df[col] = df[col].apply(
                lambda x: int(x, 16) if isinstance(x, str)
                          and x.startswith("0x") else x
            )
    return df


def encode_categoricals(df: pd.DataFrame,
                         cat_cols: list,
                         strategy: str = "onehot") -> pd.DataFrame:
    """Encode categorical columns.

    Parameters
    ----------
    cat_cols : list
        Column names to encode.
    strategy : str
        'onehot' (default, recommended) or 'label'.
    """
    existing = [c for c in cat_cols if c in df.columns]
    if not existing:
        return df

    if strategy == "onehot":
        df = pd.get_dummies(df, columns=existing, drop_first=True)
        print(f"  One-hot encoded: {existing}")
    else:
        le = LabelEncoder()
        for col in existing:
            df[col] = df[col].fillna("Unknown").astype(str)
            df[col] = le.fit_transform(df[col])
        print(f"  Label encoded: {existing}")

    return df


def impute_missing(df: pd.DataFrame,
                   label_col: str,
                   strategy: str = "mean") -> pd.DataFrame:
    """Impute missing values in feature columns (not the label)."""
    feature_cols = [c for c in df.columns if c != label_col]
    imputer = SimpleImputer(strategy=strategy)
    df[feature_cols] = imputer.fit_transform(df[feature_cols])
    print(f"  Imputed missing values (strategy='{strategy}')")
    return df


def scale_features(df: pd.DataFrame, label_col: str) -> pd.DataFrame:
    """Apply StandardScaler to all numeric feature columns."""
    feature_cols = df.drop(columns=[label_col]).select_dtypes(
        include=["float64", "int64", "uint8"]
    ).columns.tolist()

    scaler = StandardScaler()
    df[feature_cols] = scaler.fit_transform(df[feature_cols])
    print(f"  Scaled {len(feature_cols)} numeric feature columns")
    return df


def split_X_y(df: pd.DataFrame, label_col: str):
    """Return (X, y) as DataFrames/Series."""
    X = df.drop(columns=[label_col])
    y = df[label_col]
    print(f"  X shape: {X.shape}   |   Class distribution:\n"
          f"    {y.value_counts().to_dict()}")
    return X, y


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------

def preprocess(file_path: str,
               dataset: str = "unsw",
               sample_frac: float = 1.0,
               encode_strategy: str = "onehot",
               output_path: str = None) -> tuple:
    """End-to-end preprocessing pipeline.

    Parameters
    ----------
    file_path : str
        Raw CSV input path.
    dataset : str
        'unsw' or 'bot'.
    sample_frac : float
        Fraction of data to use.
    encode_strategy : str
        'onehot' or 'label'.
    output_path : str
        If provided, saves preprocessed CSV here.

    Returns
    -------
    X : pd.DataFrame
    y : pd.Series
    """
    label_col = UNSW_LABEL_COL if dataset == "unsw" else BOT_LABEL_COL
    cat_cols  = UNSW_CAT_COLS  if dataset == "unsw" else BOT_CAT_COLS

    print("\n=== Preprocessing ===")

    df = load_data(file_path, sample_frac=sample_frac)
    df = drop_irrelevant_columns(df, dataset=dataset)
    df = convert_hex_columns(df)
    df = df.fillna(0)  # fill remaining NaNs with 0 before encoding
    df = encode_categoricals(df, cat_cols, strategy=encode_strategy)
    df = impute_missing(df, label_col=label_col)
    df = scale_features(df, label_col=label_col)

    X, y = split_X_y(df, label_col=label_col)

    if output_path:
        df.to_csv(output_path, index=False)
        print(f"  Saved preprocessed data → {output_path}")

    print("=== Preprocessing complete ===\n")
    return X, y


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(description="AEGIS-IoT Preprocessing")
    p.add_argument("--input",    required=True,
                   help="Path to raw CSV file")
    p.add_argument("--dataset",  default="unsw", choices=["unsw", "bot"],
                   help="Dataset type (default: unsw)")
    p.add_argument("--sample",   type=float, default=1.0,
                   help="Fraction of data to sample (default: 1.0)")
    p.add_argument("--output",   default=None,
                   help="Path to save preprocessed CSV")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    X, y = preprocess(
        file_path=args.input,
        dataset=args.dataset,
        sample_frac=args.sample,
        output_path=args.output,
    )
    print(f"Ready: X={X.shape}, y={y.shape}")
