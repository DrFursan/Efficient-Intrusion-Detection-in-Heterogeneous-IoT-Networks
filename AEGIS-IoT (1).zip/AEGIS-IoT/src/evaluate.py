"""
evaluate.py
===========
Shared evaluation utilities: metrics, confusion matrix,
CSV / TXT export, and timing helpers.
"""

import csv
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)


# ---------------------------------------------------------------------------
# Metrics summary
# ---------------------------------------------------------------------------

def compute_metrics(y_true, y_pred) -> dict:
    """Return a dict of standard classification metrics (macro average)."""
    return {
        "accuracy":  accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="macro",
                                     zero_division=0),
        "recall":    recall_score(y_true, y_pred, average="macro",
                                  zero_division=0),
        "f1":        f1_score(y_true, y_pred, average="macro",
                              zero_division=0),
    }


def print_metrics(metrics: dict, model_name: str = "Model") -> None:
    """Pretty-print a metrics dict."""
    sep = "-" * 45
    print(f"\n{sep}")
    print(f"  {model_name} — Evaluation Summary")
    print(sep)
    for k, v in metrics.items():
        print(f"  {k:<12}: {v:.4f}")
    print(sep)


# ---------------------------------------------------------------------------
# Confusion matrix
# ---------------------------------------------------------------------------

def plot_confusion_matrix(y_true, y_pred,
                           model_name: str = "Model",
                           save_path: str = None) -> np.ndarray:
    """Plot and optionally save a confusion matrix heatmap.

    Returns the confusion matrix array.
    """
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Normal", "Attack"],
        yticklabels=["Normal", "Attack"],
        ax=ax,
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix — {model_name}")
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Confusion matrix figure → {save_path}")
    plt.close()
    return cm


# ---------------------------------------------------------------------------
# File export
# ---------------------------------------------------------------------------

def save_classification_report_csv(y_true, y_pred,
                                    csv_path: str) -> None:
    """Save the sklearn classification report as a CSV."""
    report = classification_report(y_true, y_pred, zero_division=0)
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["class", "precision", "recall",
                          "f1-score", "support"])
        for line in report.splitlines():
            parts = line.split()
            if parts:
                writer.writerow(parts)
    print(f"  Classification report CSV → {csv_path}")


def save_confusion_matrix_csv(cm: np.ndarray, csv_path: str) -> None:
    """Save a confusion matrix array as a CSV."""
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(cm.tolist())
    print(f"  Confusion matrix CSV → {csv_path}")


def save_results_txt(metrics: dict,
                     y_true, y_pred,
                     cm: np.ndarray,
                     elapsed: float,
                     model_name: str,
                     txt_path: str) -> None:
    """Save a complete plain-text results report."""
    os.makedirs(os.path.dirname(txt_path) or ".", exist_ok=True)
    report = classification_report(y_true, y_pred, zero_division=0)
    with open(txt_path, "w") as f:
        f.write(f"Model: {model_name}\n")
        f.write("=" * 50 + "\n")
        f.write(f"Accuracy  : {metrics['accuracy']:.4f}\n")
        f.write(f"Precision : {metrics['precision']:.4f}  (macro)\n")
        f.write(f"Recall    : {metrics['recall']:.4f}  (macro)\n")
        f.write(f"F1-Score  : {metrics['f1']:.4f}  (macro)\n")
        f.write(f"Time      : {elapsed:.2f} s\n\n")
        f.write("Classification Report:\n")
        f.write(report + "\n")
        f.write("Confusion Matrix:\n")
        f.write(str(cm) + "\n")
    print(f"  Results TXT → {txt_path}")


# ---------------------------------------------------------------------------
# Timing context manager
# ---------------------------------------------------------------------------

class Timer:
    """Context manager that measures wall-clock elapsed time."""

    def __enter__(self):
        self._start = time.time()
        return self

    def __exit__(self, *args):
        self.elapsed = time.time() - self._start
        print(f"  Execution time: {self.elapsed:.2f} s")

    def __repr__(self):
        return f"Timer(elapsed={self.elapsed:.2f}s)"
