"""
feature_selection.py
====================
Two feature-selection strategies used in the AEGIS-IoT paper.

Scenario 1 — Information Gain + Mutual Information (manual + IG)
    Selects the union of top-k features ranked by IG and MI.

Scenario 2 — Random Forest Importance
    Trains a shallow RF, ranks features by mean decrease in impurity,
    and keeps the top-k features.

Usage
-----
    python src/feature_selection.py --scenario 1 \
        --input data/unsw_preprocessed.csv \
        --label label --topk 10

    python src/feature_selection.py --scenario 2 \
        --input data/unsw_preprocessed.csv \
        --label label --topk 9
"""

import argparse
import os

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.impute import SimpleImputer


# ---------------------------------------------------------------------------
# Scenario 1 – Information Gain / Mutual Information
# ---------------------------------------------------------------------------

def select_by_mutual_information(X: pd.DataFrame,
                                  y: pd.Series,
                                  top_k: int = 10) -> tuple:
    """Select features using Information Gain (mutual information).

    Returns the union of top-k IG features and top-k MI features
    to maximise coverage.

    Parameters
    ----------
    X : pd.DataFrame   Feature matrix.
    y : pd.Series      Binary target.
    top_k : int        Number of top features to select per method.

    Returns
    -------
    X_selected : pd.DataFrame
    selected_features : list[str]
    """
    print(f"\n[Scenario 1] Selecting top {top_k} features via IG + MI ...")

    # Impute before computing MI (MI cannot handle NaN)
    imputer = SimpleImputer(strategy="mean")
    X_imp = imputer.fit_transform(X)

    # --- Information Gain via SelectKBest -------------------------
    selector = SelectKBest(mutual_info_classif, k=top_k)
    selector.fit(X_imp, y)
    ig_indices = selector.get_support(indices=True)
    ig_features = X.columns[ig_indices].tolist()
    print(f"  IG-selected  : {ig_features}")

    # --- Mutual Information ranking --------------------------------
    mi_scores = mutual_info_classif(X_imp, y, random_state=42)
    mi_indices = mi_scores.argsort()[-top_k:][::-1]
    mi_features = X.columns[mi_indices].tolist()
    print(f"  MI-selected  : {mi_features}")

    # --- Union -----------------------------------------------------
    combined = list(set(ig_features) | set(mi_features))
    print(f"  Union ({len(combined)} features): {combined}")

    X_selected = X[combined]
    return X_selected, combined


# ---------------------------------------------------------------------------
# Scenario 2 – Random Forest Feature Importance
# ---------------------------------------------------------------------------

def select_by_rf_importance(X: pd.DataFrame,
                             y: pd.Series,
                             top_k: int = 9,
                             n_estimators: int = 100,
                             random_state: int = 42,
                             save_csv: str = None) -> tuple:
    """Select features using Random Forest mean decrease in impurity.

    Parameters
    ----------
    X : pd.DataFrame
    y : pd.Series
    top_k : int           Number of top features to keep.
    n_estimators : int    Trees in the RF used for importance ranking.
    random_state : int
    save_csv : str        If provided, saves importance scores to this path.

    Returns
    -------
    X_selected : pd.DataFrame
    selected_features : list[str]
    importance_df : pd.DataFrame   Full ranked feature importance table.
    """
    print(f"\n[Scenario 2] Selecting top {top_k} features via RF importance ...")

    # Impute before training RF
    imputer = SimpleImputer(strategy="mean")
    X_imp = imputer.fit_transform(X)

    rf = RandomForestClassifier(
        n_estimators=n_estimators,
        random_state=random_state,
        n_jobs=-1,
        class_weight="balanced",
    )
    rf.fit(X_imp, y)

    importances = rf.feature_importances_
    importance_df = pd.DataFrame({
        "feature":    X.columns,
        "importance": importances,
    }).sort_values("importance", ascending=False).reset_index(drop=True)

    print(f"\n  Top {top_k} features by RF importance:")
    print(importance_df.head(top_k).to_string(index=False))

    if save_csv:
        importance_df.to_csv(save_csv, index=False)
        print(f"  Saved importance scores → {save_csv}")

    selected_features = importance_df.head(top_k)["feature"].tolist()
    X_selected = X[selected_features]
    return X_selected, selected_features, importance_df


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(description="AEGIS-IoT Feature Selection")
    p.add_argument("--scenario", type=int, required=True, choices=[1, 2],
                   help="1 = IG+MI,  2 = RF importance")
    p.add_argument("--input",    required=True,
                   help="Preprocessed CSV (features + label)")
    p.add_argument("--label",    default="label",
                   help="Name of label column (default: label)")
    p.add_argument("--topk",     type=int, default=10,
                   help="Number of top features (default: 10)")
    p.add_argument("--output",   default=None,
                   help="Save selected-feature CSV here")
    p.add_argument("--importance_csv", default="results/important_features.csv",
                   help="(Scenario 2 only) save feature importance CSV")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    df = pd.read_csv(args.input)
    X  = df.drop(columns=[args.label])
    y  = df[args.label]

    if args.scenario == 1:
        X_sel, feats = select_by_mutual_information(X, y, top_k=args.topk)
    else:
        os.makedirs(os.path.dirname(args.importance_csv), exist_ok=True)
        X_sel, feats, _ = select_by_rf_importance(
            X, y,
            top_k=args.topk,
            save_csv=args.importance_csv,
        )

    print(f"\nSelected {len(feats)} features: {feats}")

    if args.output:
        out_df = X_sel.copy()
        out_df[args.label] = y.values
        out_df.to_csv(args.output, index=False)
        print(f"Saved selected dataset → {args.output}")
